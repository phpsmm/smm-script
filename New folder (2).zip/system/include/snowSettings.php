<?php

$snowEffect = array(
    "status"   =>  "1",
    "color"    =>  "#5ECDEF",
    "count"    =>  "100",
    "maxsize"  =>  "18",
    "speed"    =>  "1"
);