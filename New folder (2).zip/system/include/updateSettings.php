<?php

$updateDetails = array(
    "current"    =>  "GLYCON-SMM-V1.9.5",
    "last"       =>  "GLYCON-SMM-V1.9.5"
);            