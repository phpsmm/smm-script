<?php 
define('VERSION_NUMBER', '1.0'); //bilmiyrsanız ellemeyiniz
