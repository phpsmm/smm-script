<?php
    
    define('PATH', realpath('.'));
    define('SUBFOLDER', false);
    define('URL', 'https://wixout.com');
    define('DINAMICLISANCE', 'GLYCON-THAZV-KGEYP-RMYOL');
    
    ini_set('display_errors', 0);
    date_default_timezone_set('Europe/Istanbul');
    
    return [
      'db' => [
        'name'    =>  'u820858743_wix',
        'host'    =>  'localhost',
        'user'    =>  'u820858743_wix',
        'pass'    =>  '!Sj8xixiu]',
        'charset' =>  'utf8mb4' 
      ]
    ];
    